﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _200601038_odev1_1
{
    internal class MorphologicAnalysis
    {
    }
}
